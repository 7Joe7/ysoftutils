  Preconfigured Tomcat7 Server (version 1.0.0)
===============================================
The following changes have been made to a standard binary Tomcat 7.0.54 32-bit Windows release to allow for Payment system configuration:

1. 'payment-conf' directory added
	- a directory named payment-conf has been created within Tomcat's root
	- this directory will contain all Payment system related configuration
	
2. 'payment-conf' directory has been added to classpath
	- the common.loader property within Tomcat's conf/catalina.properties has been extended to include the payment-conf directory
	  
	  common.loader=${catalina.base}/lib,${catalina.base}/lib/*.jar,${catalina.home}/lib,${catalina.home}/lib/*.jar,${catalina.base}/payment-conf,${catalina.base}/payment-conf/*.jar,${catalina.base}/payment-conf/jdbc-drivers/*.jar
	
3. HTTPS had been enabled
	- within Tomcat's conf/server.xml file the section relating to HTTPS connector has been uncommented and set to use the following keystore and truststore: payment-conf/keystore.jks, payment-conf/truststore.jks
	  
	  <Connector protocol="org.apache.coyote.http11.Http11NioProtocol" port="8443" maxThreads="200" scheme="https" 
			   secure="true" SSLEnabled="true"
			   keystoreFile="${catalina.base}/payment-conf/keystore.jks" keystorePass="..." 
			   truststoreFile="${catalina.base}/payment-conf/truststore.jks" truststorePass="..." 
			   clientAuth="false" sslProtocol="TLS" useBodyEncodingForURI="true" />

			   
4. GET Parameter encoding
	- <Connector ... useBodyEncodingForURI="true" /> is set to have the same encoding for URI parameters as the request body
	
5. Jdbc drivers are bundled and added to classpath
	- mysql, oracle, postgres and mssql jdbc drivers are bundled within payment-conf/jdbc-drivers directory

	
  payment-conf contents
==========================
	payment-conf
	  +- jdbc-drivers
	  |   +- mysql-connector-java-5.1.6.jar
	  |   +- ojdbc6-11.2.0.jar
	  |   +- postgresql-9.3-1100-jdbc41.jar
	  |   \- sqljdbc4.jar
	  +- environment-configuration.properties
	  +- environment-configuration.properties.example
	  \- keystore.jks
  
environment-configuration.properties         - main Payment system configuration file, this file is loaded upon Payment system startup only configure what you need, leave defaults where you are not sure
environment-configuration.properties.example - example of all things that can be configured through environment-configuration.properties
mysql-connector-java-5.1.6.jar               - mysql jdbc driver
ojdbc6-11.2.0.jar                            - oracle jdbc driver
postgresql-9.3-1100-jdbc41.jar               - postgres driver
sqljdbc4.jar                                 - mssql jdbc driver
keystore.jks								 - keystore containing the server certificate


  Defaults
============
When environment-configuration.properties is empty, Payment system starts up using a. in-memory database (h2database).